package magicGame.models.magicians;

import magicGame.models.magics.Magic;

public class BlackWidow extends MagicianImpl{
    public BlackWidow(String username, int health, int protection, Magic magic) {
        super(username, health, protection, magic);
    }
}
