window.addEventListener("load", solve);

function solve() {
  const scholarshipState = {
    studentName: null,
    university: null,
    score: null,
  };
  const inputDOMSelectors = {
    studentName: document.getElementById("student"),
    university: document.getElementById("university"),
    score: document.getElementById("score"),
  };

  const otherDOMSelectors = {
    nextBtn: document.getElementById("next-btn"),
    previewList: document.getElementById("preview-list"),
  };
  otherDOMSelectors.nextBtn.addEventListener("click", nextBtnHandler);

  function nextBtnHandler() {
    if (inputDOMSelectors.studentName.value === '' || inputDOMSelectors.university.value === '' || inputDOMSelectors.score.value === ''){
      return
    }
    const li = createElement("li", otherDOMSelectors.previewList, null, [
      "application",
    ]);
    const article = createElement("article", li);
    createElement("h4", article, inputDOMSelectors.studentName.value);
    createElement(
      "p",
      article,
      `University: ${inputDOMSelectors.university.value}`
    );
    createElement("p", article, `Score: ${inputDOMSelectors.score.value}`);

    const editBtn = createElement(
      "button",
      document.querySelector("li.application"),
      "edit",
      ["action-btn"]
    );
    const applyBtn = createElement(
      "button",
      document.querySelector("li.application"),
      "apply",
      ["action-btn"]
    );

    editBtn.addEventListener("click", editBtnHandler);
    applyBtn.addEventListener("click", applyBtnHandler);

    scholarshipState.studentName = inputDOMSelectors.studentName.value;
    scholarshipState.university = inputDOMSelectors.university.value;
    scholarshipState.score = inputDOMSelectors.score.value;

    otherDOMSelectors.nextBtn.disabled = true;
    inputDOMSelectors.studentName.value = "";
    inputDOMSelectors.university.value = "";
    inputDOMSelectors.score.value = "";
  }

  function editBtnHandler() {
    otherDOMSelectors.nextBtn.disabled = false;
    inputDOMSelectors.studentName.value = scholarshipState.studentName;
    inputDOMSelectors.university.value = scholarshipState.university;
    inputDOMSelectors.score.value = scholarshipState.score;
    document.getElementById("preview-list").innerHTML = "";
  }
  function applyBtnHandler() {
    document.querySelector(".action-btn").remove();
    document.querySelector(".action-btn").remove();
    document
      .getElementById("candidates-list")
      .appendChild(document.querySelector("li.application"));
    otherDOMSelectors.nextBtn.disabled = false;
  }
  function createElement(
    type,
    parentNode,
    content,
    classes,
    id,
    attributes,
    useInnerHtml
  ) {
    const htmlElement = document.createElement(type);

    if (content && useInnerHtml) {
      htmlElement.innerHTML = content;
    } else {
      if (content && type !== "input") {
        htmlElement.textContent = content;
      }

      if (content && type === "input") {
        htmlElement.value = content;
      }
    }

    if (classes && classes.length > 0) {
      htmlElement.classList.add(...classes);
    }

    if (id) {
      htmlElement.id = id;
    }
    if (attributes) {
      for (const key in attributes) {
        htmlElement.setAttribute(key, attributes[key]);
      }
    }

    if (parentNode) {
      parentNode.appendChild(htmlElement);
    }
    return htmlElement;
  }
}
