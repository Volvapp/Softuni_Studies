import implementations.SinglyLinkedList;

public class Main {
    public static void main(String[] args) {

        SinglyLinkedList<String> singlyLinkedList = new SinglyLinkedList<>();

        singlyLinkedList.addFirst("12");
        singlyLinkedList.addFirst("12");
        singlyLinkedList.addFirst("12");
        singlyLinkedList.addLast("14");
        singlyLinkedList.addLast("13");
    }
}
